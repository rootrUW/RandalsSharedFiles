# ------------------------------------------------------------------------------------------ #
# Title: Creating Strings of Characters
# Desc: Shows how data types work
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
# ------------------------------------------------------------------------------------------ #


# Define the program's data
string_of_data: str

# Work with the data
# A String is a collection of individual characters (They are just called strings).
string_of_data = "a string of data"
print(string_of_data)

# When you add new data to a variable it deletes the old and creates a new
string_of_data = "a new string of data"
print(string_of_data)

# You can print a single character by indicating its number in the sequence
print(string_of_data[2])  # Prints out a since the numbers start at zero

# However, you cannot change an individual character the same way
# string_of_data[2] = 'N'  # ERROR!

# counter = 0
# while counter < 4:
#     print(string_of_data[counter])
#     counter = counter + 1

# You can see each the character using something called a for loop
for each_character in string_of_data:
    print(each_character, sep=" ", end=":")

# We will learn more about how the for loop works later!

