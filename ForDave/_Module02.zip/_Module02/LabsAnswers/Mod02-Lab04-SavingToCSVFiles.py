# ------------------------------------------------------------------------------------------ #
# Title: Mod02-Lab04-SavingDataToCSVFiles
# Desc: This lab demonstrates using input and output to a file
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
#   <Your Name Here>,<Date>, <Activity>
# ------------------------------------------------------------------------------------------ #

# Define the program's data
message: str
student_first_name: str
student_last_name: str
student_gpa: float
file_reference: object
file_data: str

# Open a file for data processing
# TODO: ADD CODE HERE
file_reference = open("_LabData.csv", "w")

# Capture data input for the student
# TODO: ADD CODE HERE
student_first_name = input("What is the student's first name? ")
student_last_name = input("What is the student's last name? ")
student_gpa = input("What is the student's GPA? ")

# Format the captured data for the file
# TODO: ADD CODE HERE
file_data = f"{student_first_name},{student_last_name},{student_gpa}\n"

# Write the new data string to the CSV file
# TODO: ADD CODE HERE
file_reference.write(file_data)
print("\nData Recorded!\n")

# Reformat and display the capture data input to the user
# TODO: ADD CODE HERE
message = f"Student {student_first_name} {student_last_name} " \
          f"has a {float(student_gpa):.2f} grade point average (GPA)"
print(message)

# Now, look at the file to see if it worked