# ------------------------------------------------------------------------------------------ #
# Title: Assignment03
# Desc: This assignment demonstrates using conditional logic and looping
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
#   <Your Name Here>,<Date>, <Activity>
# ------------------------------------------------------------------------------------------ #

# Define the Data Constants

# Define the Data Variables

# Present and Process the data

    # Present the menu of choices

    # Input user data

    # Present the current data

    # Save the data to a file

    # Stop the loop

