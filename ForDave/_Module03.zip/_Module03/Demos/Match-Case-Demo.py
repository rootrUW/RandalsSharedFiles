# ------------------------------------------------------------------------------------------ #
# Title: Using Match-Case
# Desc: Shows how to use the Match-Case statement block
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
# ------------------------------------------------------------------------------------------ #

# Python now includes a match-case statement block (like most other modern languages)

# Here is another example that can be used the your simple program menu
data: str = ''
menu: str = """ 
    Select and enter a number based on the following options:
    1. Enter new data
    2. Show the data       
    """

while True:
    print(menu)
    print("Enter a choice")
    choice = input("Enter a menu option (1 or 2): ")

    match choice:
        case "1":
            data = input("Enter new data: ")
            continue
        case "2":
            print(data)
            continue
        case other:
            print("Do the default behavior")
            break

# Oddly, when working with some comparisons you may have to include
# repeating variables that are not needed with the if-elif, as in this example's gpa:

print("\nShow GPA Demo\n")

total_grade_points = 4 + 3.6 + 3.8 + 3.2
grade_point_average = total_grade_points / 4

match grade_point_average:
    case gpa if gpa >= 4.0:
        message = "A GPA of {:.2f} equals an A"
    case gpa if gpa >= 3.0:
        message = "A GPA of {:.2f} equals a B"
    case gpa if gpa >= 2.0:
        message = "A GPA of {:.2f} equals a C"
    case gpa if gpa >= 1.0:
        message = "A GPA of {:.2f} equals a D"
    case _:
        message = "A GPA of {:.2f} is not a passing grade"

print(message.format(grade_point_average))

# Let's Compare this code to the elif example:
if grade_point_average >= 4.0:
    message = " A GPA of {:.2f} equals an A"
elif grade_point_average >= 3.0:
    message = "A GPA of {:.2f} equals a B"
elif grade_point_average >= 2.0:
    message = "A GPA of {:.2f} equals a C"
elif grade_point_average >= 1.0:
    message = "A GPA of {:.2f} equals a D"
else:
    message = "A GPA of {:.2f} is not a passing grade"

print(message.format(grade_point_average))

