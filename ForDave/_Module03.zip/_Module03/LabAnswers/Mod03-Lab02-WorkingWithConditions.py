# ------------------------------------------------------------------------------------------ #
# Title: Working with conditions
# Desc: Shows how conditional logic statements work
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
# ------------------------------------------------------------------------------------------ #

# Define the program's data
message: str = ''
student_first_name: str = ''
student_last_name: str = ''
student_gpa: float = 0.0

# Input the data
student_first_name = input("What is the student's first name? ")
student_last_name = input("What is the student's last name? ")
student_gpa = float(input("What is the student's GPA? "))

# Process the data to create custom messages
if student_gpa >= 4.0:
    message = "{} {} earned an A with a {:.2f} GPA"
elif student_gpa >= 3.0:
    message = " {} {} earned a B with a {:.2f} GPA"
elif student_gpa >= 2.0:
    message = "{} {} earned a C with a {:.2f} GPA"
elif student_gpa >= 1.0:
    message = "{} {} earned a D with a {:.2f} GPA"
else:
    message = "{} {}'s {:.2f} GPA was not a passing grade"

print(message.format(student_first_name, student_last_name, student_gpa))

input("Pausing until you use the Enter key again ...")
